// File: /functions/api/auth/register.js

/**
 * Utility function untuk hashing password dengan salt (aman).
 * Menggunakan Web Crypto API (bawaan Cloudflare Workers).
 */
async function hashPassword(password, salt) {
  const enc = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    enc.encode(password),
    { name: 'PBKDF2' },
    false,
    ['deriveBits']
  );
  const pbkdf2Bits = await crypto.subtle.deriveBits(
    {
      name: 'PBKDF2',
      salt: enc.encode(salt),
      iterations: 100000,
      hash: 'SHA-256',
    },
    keyMaterial,
    256
  );
  const hashArray = Array.from(new Uint8Array(pbkdf2Bits));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  return hashHex;
}

/**
 * Menangani permintaan POST untuk registrasi user baru.
 */
export async function onRequestPost(context) {
  try {
    const { request, env } = context;
    const body = await request.json();
    const { name, email, password } = body;

    // 1. Validasi input
    if (!name || !email || !password) {
      return new Response(JSON.stringify({ error: 'Nama, email, dan password wajib diisi.' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    // 2. Cek apakah email sudah terdaftar
    const db = env.DB;
    const existingUser = await db.prepare('SELECT id FROM users WHERE email = ?').bind(email).first();
    if (existingUser) {
      return new Response(JSON.stringify({ error: 'Email ini sudah terdaftar.' }), {
        status: 409, // 409 Conflict
        headers: { 'Content-Type': 'application/json' },
      });
    }

    // 3. Buat salt dan hash password
    const salt = crypto.randomUUID().replaceAll('-', '');
    const password_hash = await hashPassword(password, salt);

    // 4. Masukkan user baru ke database
    const { meta } = await db.prepare(
      'INSERT INTO users (name, email, password_hash, salt) VALUES (?, ?, ?, ?)'
    ).bind(name, email, password_hash, salt).run();
    
    const userId = meta.last_row_id;

    // 5. Buat session token
    const sessionToken = crypto.randomUUID();
    await db.prepare('INSERT INTO sessions (token, user_id) VALUES (?, ?)')
      .bind(sessionToken, userId)
      .run();

    // 6. Kembalikan data (termasuk token untuk auto-login)
    return new Response(JSON.stringify({
      message: 'Registrasi sukses!',
      token: sessionToken,
      user: { id: userId, name: name, email: email, avatarUrl: null }
    }), {
      status: 201, // 201 Created
      headers: { 'Content-Type': 'application/json' },
    });

  } catch (err) {
    console.error(err);
    return new Response(JSON.stringify({ error: err.message || 'Kesalahan server.' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
}