// File: /functions/api/auth/login.js

/**
 * Utility function untuk hashing password (HARUS SAMA DENGAN DI REGISTER.JS)
 */
async function hashPassword(password, salt) {
  const enc = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    enc.encode(password),
    { name: 'PBKDF2' },
    false,
    ['deriveBits']
  );
  const pbkdf2Bits = await crypto.subtle.deriveBits(
    {
      name: 'PBKDF2',
      salt: enc.encode(salt),
      iterations: 100000,
      hash: 'SHA-256',
    },
    keyMaterial,
    256
  );
  const hashArray = Array.from(new Uint8Array(pbkdf2Bits));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  return hashHex;
}

/**
 * Menangani permintaan POST untuk login.
 */
export async function onRequestPost(context) {
  try {
    const { request, env } = context;
    const body = await request.json();
    const { email, password } = body;

    // 1. Validasi input
    if (!email || !password) {
      return new Response(JSON.stringify({ error: 'Email dan password wajib diisi.' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    // 2. Cari user berdasarkan email
    const db = env.DB;
    const user = await db.prepare('SELECT id, name, email, password_hash, salt, avatar_url FROM users WHERE email = ?')
      .bind(email)
      .first();

    if (!user) {
      return new Response(JSON.stringify({ error: 'Email atau password salah.' }), {
        status: 401, // Unauthorized
        headers: { 'Content-Type': 'application/json' },
      });
    }

    // 3. Verifikasi password
    const inputHash = await hashPassword(password, user.salt);
    
    if (inputHash !== user.password_hash) {
      return new Response(JSON.stringify({ error: 'Email atau password salah.' }), {
        status: 401, // Unauthorized
        headers: { 'Content-Type': 'application/json' },
      });
    }

    // 4. Buat session token baru
    const sessionToken = crypto.randomUUID();
    await db.prepare('INSERT INTO sessions (token, user_id) VALUES (?, ?)')
      .bind(sessionToken, user.id)
      .run();
    
    // (Opsional: hapus session lama user ini agar tidak menumpuk)
    // await db.prepare('DELETE FROM sessions WHERE user_id = ? AND token != ?')
    //   .bind(user.id, sessionToken)
    //   .run();

    // 5. Kembalikan data (termasuk token)
    return new Response(JSON.stringify({
      message: 'Login sukses!',
      token: sessionToken,
      user: { id: user.id, name: user.name, email: user.email, avatarUrl: user.avatar_url }
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });

  } catch (err) {
    console.error(err);
    return new Response(JSON.stringify({ error: err.message || 'Kesalahan server.' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
}